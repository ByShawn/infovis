import base64
import csv
import io
import json
import re
from pathlib import Path
from typing import Any, Dict, List

import streamlit.components.v1 as components


DEFAULT_CSV = """month,sales,profit
Jan,120,32
Feb,200,58
Mar,150,41
Apr,260,73
May,310,96
Jun,280,84
"""


def decode_csv_bytes(raw: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "gbk"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def parse_csv(csv_text: str) -> tuple[List[Dict[str, Any]], List[str]]:
    reader = csv.DictReader(io.StringIO(csv_text))
    if not reader.fieldnames:
        raise ValueError("CSV 必须包含表头。")

    rows = [
        {key: _coerce_value(value or "") for key, value in row.items() if key}
        for row in reader
    ]
    if not rows:
        raise ValueError("CSV 至少需要一行数据。")
    return rows, [field for field in reader.fieldnames if field]


def image_to_data_url(image_bytes: bytes, mime_type: str) -> str:
    encoded = base64.b64encode(image_bytes).decode("ascii")
    return f"data:{mime_type};base64,{encoded}"


def parse_json_object(text: str) -> Dict[str, Any]:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{[\s\S]*\}", text)
        if not match:
            raise ValueError("模型没有返回 JSON 对象。")
        return json.loads(match.group(0))


def render_generated_chart(
    generated: Dict[str, Any],
    data: List[Dict[str, Any]],
    columns: List[str],
) -> None:
    echarts_js = _read_asset("lib/echarts.min.js")
    d3_js = _read_asset("lib/d3.v3.min.js")
    code = generated.get("code", "")

    html = f"""
    <div id="chart-root" style="width:100%;height:520px;border:1px solid #e5e7eb;border-radius:8px;"></div>
    <pre id="chart-error" style="white-space:pre-wrap;color:#b91c1c;font-size:13px;"></pre>
    <script>{echarts_js}</script>
    <script>{d3_js}</script>
    <script>
      const data = {_to_js(data)};
      const columns = {_to_js(columns)};
      const generatedCode = {_to_js(code)};
      const container = document.getElementById("chart-root");
      const errorBox = document.getElementById("chart-error");

      try {{
        container.innerHTML = "";
        const factory = new Function(generatedCode + "\\n; return typeof renderChart === 'function' ? renderChart : null;");
        const renderChart = factory();
        if (!renderChart) {{
          throw new Error("生成代码必须定义 function renderChart(container, data, columns)");
        }}
        renderChart(container, data, columns);
      }} catch (err) {{
        errorBox.textContent = err && err.stack ? err.stack : String(err);
      }}
    </script>
    """
    components.html(html, height=600, scrolling=True)


def render_status_log(status_box, lines: List[str]) -> None:
    status_box.markdown("\n".join(f"- {line}" for line in lines))


def _coerce_value(value: str) -> Any:
    value = value.strip()
    if value == "":
        return ""
    if re.fullmatch(r"[-+]?\d+", value):
        return int(value)
    if re.fullmatch(r"[-+]?\d*\.\d+", value):
        return float(value)
    return value


def _read_asset(path: str) -> str:
    asset_path = Path(__file__).parent / path
    if not asset_path.exists():
        return ""
    return asset_path.read_text(encoding="utf-8")


def _to_js(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False).replace("</", "<\\/")
