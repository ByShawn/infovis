import base64
import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any, Dict, List

from langchain_openai import ChatOpenAI


@dataclass
class LLMResponse:
    content: str


class GeminiVisionClient:
    def __init__(self, api_key: str, base_url: str, model: str, temperature: float) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.temperature = temperature

    def invoke(self, messages: List[Dict[str, Any]]) -> LLMResponse:
        system_text = ""
        user_parts: List[Dict[str, Any]] = []

        for message in messages:
            role = message.get("role", "")
            content = message.get("content", "")
            if role == "system":
                system_text = str(content)
                continue

            if isinstance(content, str):
                user_parts.append({"text": content})
                continue

            for item in content:
                if item.get("type") == "text":
                    user_parts.append({"text": item.get("text", "")})
                elif item.get("type") == "image_url":
                    image_url = item.get("image_url", {}).get("url", "")
                    user_parts.append(self._image_part(image_url))

        payload: Dict[str, Any] = {
            "contents": [{"role": "user", "parts": user_parts}],
            "generationConfig": {"temperature": self.temperature},
        }
        if system_text:
            payload["systemInstruction"] = {"parts": [{"text": system_text}]}

        request = urllib.request.Request(
            self._endpoint(),
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
                "x-goog-api-key": self.api_key,
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(request, timeout=120) as response:
                body = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"LLM 请求失败：HTTP {exc.code}，{body[:500]}") from exc

        data = json.loads(body)
        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        text = "".join(part.get("text", "") for part in parts)
        if not text:
            raise RuntimeError(f"LLM 没有返回文本内容：{body[:500]}")
        return LLMResponse(content=text)

    def _endpoint(self) -> str:
        base_url = self.base_url
        if base_url.endswith("/v1beta"):
            root = base_url
        else:
            root = f"{base_url}/v1beta"

        model = urllib.parse.quote(self.model, safe="")
        query = urllib.parse.urlencode({"key": self.api_key})
        return f"{root}/models/{model}:generateContent?{query}"

    @staticmethod
    def _image_part(data_url: str) -> Dict[str, Any]:
        if not data_url.startswith("data:") or "," not in data_url:
            raise ValueError("图片必须是 data URL。")

        header, encoded = data_url.split(",", 1)
        mime_type = header.removeprefix("data:").split(";")[0] or "image/png"
        # Validate base64 early so request errors are easier to understand.
        base64.b64decode(encoded, validate=True)
        return {"inline_data": {"mime_type": mime_type, "data": encoded}}


def build_vision_llm(api_key: str, base_url: str, model: str, temperature: float):
    normalized_base_url = base_url.rstrip("/")
    is_gemini = model.lower().startswith("gemini")
    is_openai_compat = "/openai" in normalized_base_url.lower()

    if is_gemini and not is_openai_compat:
        return GeminiVisionClient(
            api_key=api_key,
            base_url=normalized_base_url,
            model=model,
            temperature=temperature,
        )

    return ChatOpenAI(
        model=model,
        temperature=temperature,
        api_key=api_key,
        base_url=normalized_base_url,
    )
