import os
from pathlib import Path
from typing import Dict


DEFAULT_GOOGLE_BASE_URL = "https://api.openai-proxy.org/google"
DEFAULT_GOOGLE_MODEL_NAME = "gemini-3-flash-preview"


def load_env_file(path: str = ".env") -> Dict[str, str]:
    env_path = Path(__file__).parent / path
    values: Dict[str, str] = {}
    if not env_path.exists():
        return values

    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        values[key] = value
        os.environ.setdefault(key, value)

    return values


def get_llm_config(
    api_key_override: str = "",
    base_url_override: str = "",
    model_override: str = "",
) -> Dict[str, str]:
    load_env_file()
    api_key = (
        api_key_override
        or os.environ.get("API_KEY", "")
        or os.environ.get("OPENAI_API_KEY", "")
    )
    if api_key.strip() in {"", "your_api_key"}:
        api_key = ""
    base_url = (
        base_url_override
        or os.environ.get("GOOGLE_BASE_URL", "")
        or DEFAULT_GOOGLE_BASE_URL
    )
    model = (
        model_override
        or os.environ.get("GOOGLE_MODEL_NAME", "")
        or DEFAULT_GOOGLE_MODEL_NAME
    )
    return {
        "api_key": api_key,
        "base_url": base_url,
        "model": model,
    }
