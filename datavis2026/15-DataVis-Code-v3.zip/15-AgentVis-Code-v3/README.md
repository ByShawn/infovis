# 图表复现 Agent 课堂练习

一个 Streamlit 应用中包含三个练习：

- 练习 1：图表生成 Agent
- 练习 2：图表生成 Agent + 图表评审 Agent
- 练习 3：双 Agent 循环迭代

前端只展示输入接口、当前状态和输出结果。模型 URL、模型名称、API key 和 prompt 都保留在代码或 `.env` 中。

## 安装依赖

```bash
pip install streamlit langgraph langchain-openai
```

## 配置 `.env`

运行前从 `.env.example` 复制出 `.env` 文件，并把其中的 `API_KEY` 改成可用密钥，其他不要改动：

```bash
API_KEY=your_api_key
```

## 运行

运行总入口：

```bash
streamlit run app.py
```

打开网页后，在左侧选择练习 1、练习 2 或练习 3。

也可以单独运行某个练习：

```bash
streamlit run exercise1_chart_generation.py
streamlit run exercise2_generation_review.py
streamlit run exercise3_iterative_agents.py
```

## 使用方式

每个练习的前端输入相同：

- 上传参考图表图片。
- 上传 CSV 文件，或直接编辑默认 CSV 内容。
- 点击运行按钮。

运行过程中，“当前状态”区域会实时展示 agent 进度。

## 三个练习

### 练习 1：图表生成 Agent

输入参考图表图片和 CSV 数据，生成可运行的 ECharts 或 D3 代码，并用 CSV 数据渲染新图表。

流程：

```text
参考图表图片 + CSV
↓
Chart Generation Agent
↓
ECharts / D3 renderChart 代码
↓
新图表
```

### 练习 2：生成 + 评审 Agent

在练习 1 的基础上增加评审 Agent。评审 Agent 会检查：

- 生成图表与参考图表有哪些视觉差异。
- 生成代码是否适配 CSV 数据。
- 是否存在写死数据或字段映射不合理的问题。
- 给出评分和修改建议。

### 练习 3：双 Agent 循环迭代

评审 Agent 的建议会返回给生成 Agent，生成 Agent 根据建议重新生成。默认最多迭代 3 次，目标分数为 85。

流程：

```text
Generation Agent
↓
Review Agent
↓
score >= 85 或 iteration >= 3：结束
否则：把 suggestions 返回给 Generation Agent
```

## 主要文件

- `app.py`：总入口，左侧选择三个练习。
- `exercise1_chart_generation.py`：练习 1 页面和生成 Agent 图。
- `exercise2_generation_review.py`：练习 2 页面、生成 Agent 和评审 Agent 图。
- `exercise3_iterative_agents.py`：练习 3 页面、循环迭代图。
- `chart_agent_common.py`：CSV 解析、图片编码、JSON 解析、图表渲染等公共逻辑。
- `chart_agent_prompts.py`：默认生成 prompt 和评审 prompt，后续可挖空给学生。
- `chart_agent_prompts_todo.py`：prompt 挖空版，包含 TODO 注释。
- `exercise3_iterative_agents_todo.py`：练习 3 挖空版，包含 TODO 注释。
- `chart_agent_config.py`：读取 `.env` 中的模型配置。
- `llm_client.py`：LLM 调用封装，支持当前 Gemini Vision 接口。
- `lib/echarts.min.js`、`lib/d3.v3.min.js`：本地图表渲染依赖。
