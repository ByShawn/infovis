import json
from typing import Any, Dict, List, TypedDict

import streamlit as st
from chart_agent_common import (
    DEFAULT_CSV,
    decode_csv_bytes,
    image_to_data_url,
    parse_csv,
    parse_json_object,
    render_generated_chart,
    render_status_log,
)
from chart_agent_config import get_llm_config
from chart_agent_prompts import DEFAULT_GENERATION_PROMPT
from langgraph.graph import END, StateGraph
from llm_client import build_vision_llm


class ChartState(TypedDict, total=False):
    api_key: str
    base_url: str
    model: str
    image_data_url: str
    csv_text: str
    data: List[Dict[str, Any]]
    columns: List[str]
    prompt: str
    preferred_library: str
    generated: Dict[str, Any]


def build_llm(api_key: str, base_url: str, model: str):
    return build_vision_llm(api_key=api_key, base_url=base_url, model=model, temperature=0.2)


def generate_chart_code(state: ChartState) -> ChartState:
    llm = build_llm(state["api_key"], state["base_url"], state["model"])
    sample_rows = state["data"][:8]
    library_hint = (
        "你可以自行选择 ECharts 或 D3。"
        if state["preferred_library"] == "auto"
        else f"请优先使用 {state['preferred_library']}。"
    )

    user_text = f"""请根据参考图表图片和 CSV 数据生成图表复现代码。

{library_hint}

CSV 字段：
{state["columns"]}

CSV 前几行：
{json.dumps(sample_rows, ensure_ascii=False, indent=2)}

完整 CSV 文本：
{state["csv_text"]}
"""

    response = llm.invoke(
        [
            {"role": "system", "content": state["prompt"]},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_text},
                    {"type": "image_url", "image_url": {"url": state["image_data_url"]}},
                ],
            },
        ]
    )
    generated = parse_json_object(response.content)
    if "code" not in generated:
        raise ValueError("生成结果缺少 code 字段。")
    generated["library"] = generated.get("library", "echarts").lower()
    return {"generated": generated}


def build_graph():
    graph = StateGraph(ChartState)
    graph.add_node("generate_chart_code", generate_chart_code)
    graph.set_entry_point("generate_chart_code")
    graph.add_edge("generate_chart_code", END)
    return graph.compile()


def render_page() -> None:
    st.title("练习 1：图表生成 Agent")
    st.caption("输入参考图表图片和 CSV 文件，生成能复现原图风格并适配 CSV 数据的 ECharts 或 D3 代码。")
    llm_config = get_llm_config()

    left, right = st.columns([0.95, 1.05])

    with left:
        st.subheader("输入")
        image_file = st.file_uploader("参考图表图片", type=["png", "jpg", "jpeg", "webp"])
        csv_file = st.file_uploader("CSV 文件", type=["csv"])

        if image_file:
            st.image(image_file, caption="参考图表", use_container_width=True)

        if csv_file:
            csv_text = decode_csv_bytes(csv_file.getvalue())
        else:
            csv_text = DEFAULT_CSV

        csv_text = st.text_area("CSV 内容", value=csv_text, height=180)
        run_button = st.button("生成图表代码", type="primary", use_container_width=True)

    with right:
        st.subheader("当前状态")
        status_box = st.empty()
        if not llm_config["api_key"]:
            status_box.warning("未配置 API_KEY。请先在项目根目录 `.env` 中填写 API_KEY。")
        elif not image_file:
            status_box.info("等待上传参考图表图片。")
        else:
            status_box.success("输入已就绪，可以运行生成 Agent。")

        st.subheader("输出")
        if run_button:
            if not llm_config["api_key"]:
                status_box.error("运行失败：未配置 API_KEY。")
                return
            if not image_file:
                status_box.error("运行失败：请上传参考图表图片。")
                return

            try:
                status_lines = ["正在解析 CSV 和参考图表图片..."]
                render_status_log(status_box, status_lines)
                data, columns = parse_csv(csv_text)
                image_bytes = image_file.getvalue()
                image_data_url = image_to_data_url(image_bytes, image_file.type or "image/png")
                state: ChartState = {
                    "api_key": llm_config["api_key"],
                    "base_url": llm_config["base_url"],
                    "model": llm_config["model"],
                    "image_data_url": image_data_url,
                    "csv_text": csv_text,
                    "data": data,
                    "columns": columns,
                    "prompt": DEFAULT_GENERATION_PROMPT,
                    "preferred_library": "auto",
                }

                with st.spinner("生成 Agent 正在分析原图并生成代码..."):
                    status_lines.append("生成 Agent 正在分析原图并生成代码...")
                    render_status_log(status_box, status_lines)
                    result: ChartState = {**state}
                    for chunk in build_graph().stream(state, stream_mode="updates"):
                        for node_name, update in chunk.items():
                            result.update(update)
                            if node_name == "generate_chart_code":
                                status_lines.append("生成 Agent 已完成图表代码生成。")
                                render_status_log(status_box, status_lines)

                generated = result["generated"]
                status_lines.append("图表渲染准备完成。")
                render_status_log(status_box, status_lines)
                st.success("生成完成")
                render_generated_chart(generated, data, columns)

                tabs = st.tabs(["生成代码", "字段与说明", "CSV 数据"])
                with tabs[0]:
                    st.code(generated.get("code", ""), language="javascript")
                with tabs[1]:
                    st.write(f"代码库：`{generated.get('library', 'unknown')}`")
                    st.json(generated.get("notes", []))
                with tabs[2]:
                    st.dataframe(data, use_container_width=True)

            except Exception as exc:
                st.error(f"运行失败：{exc}")
        else:
            st.info("上传参考图表和 CSV 后，点击左侧按钮运行。")


def main() -> None:
    st.set_page_config(page_title="练习 1：图表生成 Agent", layout="wide")
    render_page()


if __name__ == "__main__":
    main()
