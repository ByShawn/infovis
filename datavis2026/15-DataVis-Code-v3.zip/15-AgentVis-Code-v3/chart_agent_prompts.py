"""
TODO 版本：请学生补全图表生成 Agent 和图表评审 Agent 的提示词。

要求：
1. 生成 Agent 必须输出 JSON，包含 library、code、notes。
2. code 必须定义 function renderChart(container, data, columns)。
3. 评审 Agent 必须输出 JSON，包含 score、差异、CSV 适配问题和修改建议。
"""


# TODO: 练习 1 / 练习 2
# 设计图表生成 Agent Prompt。
# 目标：根据参考图表图片和 CSV 数据，生成可运行的 ECharts 或 D3 代码。
# 提示词应约束：
# - 尽量复现原图的图表类型、布局、颜色、标题、坐标轴、图例、标注、网格线和整体风格。
# - 必须从 data 参数读取 CSV 数据，不要写死数据。
# - 必须输出 JSON，不要输出 Markdown。
# - JSON 中必须包含 library、code、notes。
# - code 中必须定义 function renderChart(container, data, columns)。
DEFAULT_GENERATION_PROMPT = """
TODO: 在这里补全图表生成 Agent Prompt。
"""


# TODO: 练习 3
# 在生成 Prompt 中加入“根据上一轮评审建议修正图表”的要求。
# 可以复用 DEFAULT_GENERATION_PROMPT，也可以重写一个更适合迭代流程的生成 Prompt。
DEFAULT_ITERATIVE_GENERATION_PROMPT = """
TODO: 在这里补全支持迭代修正的图表生成 Agent Prompt。
"""


# TODO: 练习 2
# 设计图表评审 Agent Prompt。
# 目标：评价生成图表是否复现参考图，并检查代码是否适配 CSV 数据。
# 提示词应约束：
# - 输出 0-100 的总分 score。
# - 说明与参考图表的视觉差异。
# - 检查字段映射、数据读取、是否写死数据。
# - 给出可执行的修改建议 suggestions。
# - 必须输出 JSON，不要输出 Markdown。
DEFAULT_REVIEW_PROMPT = """
TODO: 在这里补全图表评审 Agent Prompt。
"""


# TODO: 练习 3
# 在评审 Prompt 中强调 suggestions 必须能直接给下一轮生成 Agent 使用。
# 可以复用 DEFAULT_REVIEW_PROMPT，也可以重写一个更适合迭代流程的评审 Prompt。
DEFAULT_ITERATIVE_REVIEW_PROMPT = """
TODO: 在这里补全支持循环迭代的图表评审 Agent Prompt。
"""
