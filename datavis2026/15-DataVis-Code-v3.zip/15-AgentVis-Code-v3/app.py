import streamlit as st

from exercise1_chart_generation import render_page as render_exercise_1
from exercise2_generation_review import render_page as render_exercise_2
from exercise3_iterative_agents import render_page as render_exercise_3


EXERCISES = {
    "练习 1：图表生成 Agent": render_exercise_1,
    "练习 2：生成 + 评审 Agent": render_exercise_2,
    "练习 3：双 Agent 循环迭代": render_exercise_3,
}


def main() -> None:
    st.set_page_config(page_title="图表复现 Agent 课堂练习", layout="wide")

    st.sidebar.title("练习导航")
    selected = st.sidebar.radio("选择练习", list(EXERCISES.keys()))
    st.sidebar.divider()
    st.sidebar.caption("运行前请在项目根目录 `.env` 中配置 `API_KEY`。")

    EXERCISES[selected]()


if __name__ == "__main__":
    main()
