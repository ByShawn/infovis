import json
from typing import Any, Dict, List, Literal, TypedDict

import streamlit as st
from chart_agent_common import (
    DEFAULT_CSV,
    decode_csv_bytes,
    image_to_data_url,
    parse_csv,
    parse_json_object,
    render_generated_chart,
    render_status_log,
)
from chart_agent_config import get_llm_config
from chart_agent_prompts import (
    DEFAULT_ITERATIVE_GENERATION_PROMPT,
    DEFAULT_ITERATIVE_REVIEW_PROMPT,
)
from langgraph.graph import END, StateGraph
from llm_client import build_vision_llm


# TODO: 设置循环迭代的目标分数。
# 建议：80-90 之间，例如 85。
DEFAULT_TARGET_SCORE = 0

# TODO: 设置最大迭代次数。
# 建议：最多 3 次，避免课堂运行时间过长。
DEFAULT_MAX_ITERATIONS = 0


class ChartState(TypedDict, total=False):
    api_key: str
    base_url: str
    model: str
    image_data_url: str
    csv_text: str
    data: List[Dict[str, Any]]
    columns: List[str]
    generation_prompt: str
    review_prompt: str
    preferred_library: str
    generated: Dict[str, Any]
    review: Dict[str, Any]
    feedback: str
    iteration: int
    max_iterations: int
    target_score: int
    history: List[Dict[str, Any]]


def build_llm(api_key: str, base_url: str, model: str, temperature: float):
    return build_vision_llm(
        api_key=api_key,
        base_url=base_url,
        model=model,
        temperature=temperature,
    )


def generation_agent(state: ChartState) -> ChartState:
    llm = build_llm(state["api_key"], state["base_url"], state["model"], temperature=0.2)
    library_hint = (
        "你可以自行选择 ECharts 或 D3。"
        if state["preferred_library"] == "auto"
        else f"请优先使用 {state['preferred_library']}。"
    )
    feedback = state.get("feedback", "")
    feedback_text = f"\n上一轮评审建议：\n{feedback}\n" if feedback else ""

    user_text = f"""这是第 {state.get("iteration", 1)} 轮生成。

请根据参考图表图片和 CSV 数据生成图表复现代码。
{library_hint}
{feedback_text}

CSV 字段：
{state["columns"]}

CSV 前几行：
{json.dumps(state["data"][:8], ensure_ascii=False, indent=2)}

完整 CSV 文本：
{state["csv_text"]}
"""

    response = llm.invoke(
        [
            {"role": "system", "content": state["generation_prompt"]},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_text},
                    {"type": "image_url", "image_url": {"url": state["image_data_url"]}},
                ],
            },
        ]
    )
    generated = parse_json_object(response.content)
    if "code" not in generated:
        raise ValueError("生成结果缺少 code 字段。")
    generated["library"] = generated.get("library", "echarts").lower()

    history = [*state.get("history", [])]
    history.append(
        {
            "iteration": state.get("iteration", 1),
            "type": "generation",
            "generated": generated,
        }
    )
    return {"generated": generated, "history": history}


def review_agent(state: ChartState) -> ChartState:
    llm = build_llm(state["api_key"], state["base_url"], state["model"], temperature=0)
    user_text = f"""请评审第 {state.get("iteration", 1)} 轮生成结果。

CSV 字段：
{state["columns"]}

CSV 前几行：
{json.dumps(state["data"][:10], ensure_ascii=False, indent=2)}

生成结果：
{json.dumps(state["generated"], ensure_ascii=False, indent=2)}

请重点判断：
- 与参考图表相比有哪些视觉差异。
- 代码是否真正适配 CSV 数据。
- 下一轮最应该修改哪些具体问题。
"""

    response = llm.invoke(
        [
            {"role": "system", "content": state["review_prompt"]},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": user_text},
                    {"type": "image_url", "image_url": {"url": state["image_data_url"]}},
                ],
            },
        ]
    )
    review = parse_json_object(response.content)
    review["score"] = int(review.get("score", 0))

    suggestions = review.get("suggestions", [])
    feedback = json.dumps(suggestions, ensure_ascii=False, indent=2)
    history = [*state.get("history", [])]
    history.append(
        {
            "iteration": state.get("iteration", 1),
            "type": "review",
            "score": review["score"],
            "review": review,
        }
    )
    return {"review": review, "feedback": feedback, "history": history}


def increase_iteration(state: ChartState) -> ChartState:
    return {"iteration": state.get("iteration", 1) + 1}


def should_continue(state: ChartState) -> Literal["revise", "end"]:
    score = int(state.get("review", {}).get("score", 0))
    iteration = state.get("iteration", 1)
    max_iterations = state.get("max_iterations", 3)
    target_score = state.get("target_score", 85)

    # TODO: 补全循环终止条件。
    # 规则：
    # - 如果 score >= target_score，返回 "end"。
    # - 如果 iteration >= max_iterations，返回 "end"。
    # - 否则返回 "revise"，让评审建议返回给生成 Agent 继续修正。
    return "end"


def build_graph():
    graph = StateGraph(ChartState)
    graph.add_node("generation_agent", generation_agent)
    graph.add_node("review_agent", review_agent)
    graph.add_node("increase_iteration", increase_iteration)

    graph.set_entry_point("generation_agent")
    graph.add_edge("generation_agent", "review_agent")
    graph.add_conditional_edges(
        "review_agent",
        should_continue,
        {
            "revise": "increase_iteration",
            "end": END,
        },
    )
    graph.add_edge("increase_iteration", "generation_agent")
    return graph.compile()


def render_page() -> None:
    st.title("练习 3：双 Agent 循环迭代 TODO")
    st.caption("TODO 版：补全最大迭代次数、目标分数和循环终止条件。")
    llm_config = get_llm_config()

    left, right = st.columns([0.95, 1.05])

    with left:
        st.subheader("输入")
        image_file = st.file_uploader("参考图表图片", type=["png", "jpg", "jpeg", "webp"])
        csv_file = st.file_uploader("CSV 文件", type=["csv"])

        if image_file:
            st.image(image_file, caption="参考图表", use_container_width=True)

        csv_text = decode_csv_bytes(csv_file.getvalue()) if csv_file else DEFAULT_CSV
        csv_text = st.text_area("CSV 内容", value=csv_text, height=160)
        run_button = st.button("开始循环迭代", type="primary", use_container_width=True)

    with right:
        st.subheader("当前状态")
        status_box = st.empty()
        if not llm_config["api_key"]:
            status_box.warning("未配置 API_KEY。请先在项目根目录 `.env` 中填写 API_KEY。")
        elif not image_file:
            status_box.info("等待上传参考图表图片。")
        else:
            status_box.success("输入已就绪，可以开始双 Agent 循环迭代。")

        st.subheader("输出")
        if run_button:
            if not llm_config["api_key"]:
                status_box.error("运行失败：未配置 API_KEY。")
                return
            if not image_file:
                status_box.error("运行失败：请上传参考图表图片。")
                return

            try:
                status_lines = ["正在解析 CSV 和参考图表图片..."]
                render_status_log(status_box, status_lines)
                data, columns = parse_csv(csv_text)
                state: ChartState = {
                    "api_key": llm_config["api_key"],
                    "base_url": llm_config["base_url"],
                    "model": llm_config["model"],
                    "image_data_url": image_to_data_url(image_file.getvalue(), image_file.type or "image/png"),
                    "csv_text": csv_text,
                    "data": data,
                    "columns": columns,
                    "generation_prompt": DEFAULT_ITERATIVE_GENERATION_PROMPT,
                    "review_prompt": DEFAULT_ITERATIVE_REVIEW_PROMPT,
                    "preferred_library": "auto",
                    "iteration": 1,
                    "max_iterations": DEFAULT_MAX_ITERATIONS,
                    "target_score": DEFAULT_TARGET_SCORE,
                    "history": [],
                }

                with st.spinner("双 Agent 正在循环迭代..."):
                    status_lines.append("第 1 轮生成 Agent 正在生成图表代码...")
                    render_status_log(status_box, status_lines)
                    result: ChartState = {**state}
                    for chunk in build_graph().stream(state, stream_mode="updates"):
                        for node_name, update in chunk.items():
                            result.update(update)
                            iteration = result.get("iteration", 1)

                            if node_name == "generation_agent":
                                status_lines.append(f"第 {iteration} 轮生成 Agent 已完成。")
                                status_lines.append(f"第 {iteration} 轮评审 Agent 正在评审...")
                            elif node_name == "review_agent":
                                review = update.get("review", {})
                                score = int(review.get("score", 0))
                                status_lines.append(f"第 {iteration} 轮评审 Agent 已完成，得分：{score}。")
                            elif node_name == "increase_iteration":
                                next_iteration = result.get("iteration", 1)
                                status_lines.append(
                                    f"第 {next_iteration} 轮生成 Agent 正在根据评审建议重新生成..."
                                )

                            render_status_log(status_box, status_lines)

                generated = result["generated"]
                review = result["review"]
                history = result.get("history", [])
                status_lines.append("双 Agent 循环迭代完成。")
                render_status_log(status_box, status_lines)
                st.success("迭代完成")

                metric_cols = st.columns(3)
                metric_cols[0].metric("最终分数", review.get("score", 0))
                metric_cols[1].metric("迭代轮次", result.get("iteration", 1))
                metric_cols[2].metric("目标分数", DEFAULT_TARGET_SCORE)

                render_generated_chart(generated, data, columns)

                tabs = st.tabs(["最终评审", "最终代码", "迭代历史", "CSV 数据"])
                with tabs[0]:
                    st.json(review)
                with tabs[1]:
                    st.write(f"代码库：`{generated.get('library', 'unknown')}`")
                    st.code(generated.get("code", ""), language="javascript")
                    st.json(generated.get("notes", []))
                with tabs[2]:
                    for item in history:
                        label = f"第 {item.get('iteration')} 轮 - {item.get('type')}"
                        with st.expander(label):
                            st.json(item)
                with tabs[3]:
                    st.dataframe(data, use_container_width=True)

            except Exception as exc:
                st.error(f"运行失败：{exc}")
        else:
            st.info("上传参考图表和 CSV 后，点击左侧按钮运行。")


def main() -> None:
    st.set_page_config(page_title="练习 3：双 Agent 循环迭代 TODO", layout="wide")
    render_page()


if __name__ == "__main__":
    main()
