function UIInit(){
	
	$( function() {
		$( "#slider" ).slider();
	} );

}